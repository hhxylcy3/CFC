import torch
import torch.nn as nn
import thop
import math

class Pfc(nn.Module):
    def __init__(self, n_class=2, input_size=224 ):
        super(Pfc, self).__init__()
        self.conv = nn.Conv2d(1,1,3,2,1)
        self.maxpool = nn.MaxPool2d(2, stride=2)    
        self.fc1 = nn.Linear(3136,1258)
        self.drop = nn.Dropout(p=0.4,inplace=False)
        self.fc2 = nn.Linear(1258,512)     

        self._initialize_weights()

    def forward(self, x):
        x = self.maxpool(self.conv(x))         #56*56*1
        x = x.view(x.size(0),-1)
        x = self.drop(self.fc1(x))
        x = self.fc2(x)     
        return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()
                

def pfc():
    model = Pfc()
    return model                
