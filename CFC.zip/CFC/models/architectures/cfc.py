import torch
import torch.nn as nn
import thop
import math
import numpy

def conv_bn(inp, oup, k,stride,p):
    return nn.Sequential(
        nn.Conv2d(inp, oup, k, stride, p, bias=False),
        nn.BatchNorm2d(oup),
        nn.ReLU6(inplace=True)      
    )

class SELayer(nn.Module):
    def __init__(self, channel, reduction=8):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
                nn.Linear(channel, channel // reduction),
                nn.ReLU(inplace=True),
                nn.Linear(channel // reduction, channel),
                nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y


class M_attn(nn.Module):
    def __init__(self, embed_dim, num_heads=8):
        super(M_attn, self).__init__()
        self.attn = torch.nn.MultiheadAttention(embed_dim,num_heads,dropout = 0.1)
        #self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def forward(self, x):        
        b,c,h,w=x.size()
        y = x.reshape(b,c,-1)
        y = y.permute(0,2,1)       
        o,attn_weights = self.attn(y,y,y)
        o = o.permute(0,2,1)        
        z = o.reshape(b,c,h,w)
        return x + z         
           
    
   
   
    
    

def conv_dw(inp, oup,stride,expand_ratio):
    hidden_dim = round(inp * expand_ratio)
    if expand_ratio == 1:
        conv_dw = nn.Sequential(
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.ReLU6(inplace=True),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )
    else:
        conv_dw = nn.Sequential(
                # pw
                nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.ReLU6(inplace=True),
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, 3, stride, 1, groups=hidden_dim, bias=False),
                nn.BatchNorm2d(hidden_dim),
                nn.ReLU6(inplace=True),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )
    return conv_dw


def conv_ccn(inp,mid, oup, k,stride,p):
    return nn.Sequential(
        nn.Conv2d(inp, mid, k, stride, p, bias=False),        
        nn.Conv2d(mid, oup, k, stride, p, bias=False),        
        nn.BatchNorm2d(oup),
        nn.ReLU6(inplace=True)      
    )

           
                
class Cfc(nn.Module):
    def __init__(self, clf_infeature):
        super(Cfc, self).__init__()
        self.conv1 = conv_bn(3, 64, 11,4,2)  #55 *55*64
        self.pool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=0, dilation=1, ceil_mode=False)   #27*27*64
        self.conv2 = conv_ccn(64,256,32,3,1,1)       #27*27*32=23328
                 
        self.fc1 = nn.Linear(23328,2048)
        self.drop1 = nn.Dropout(p=0.5,inplace=False)       
        self.fc2 = nn.Linear(2048,clf_infeature)
        self._initialize_weights()

    def forward(self, x):
        x = self.pool1(self.conv1(x))        #27 *27*64 
        x = self.conv2(x)      #28 *28*256        
        x = x.view(x.size(0),-1)       
        x = self.fc1(self.drop1(x))
        x = self.fc2(self.drop1(x))  
        
        return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()  

                
class Cfc1(nn.Module):   #未添加注意力机制
    def __init__(self, clf_infeature=512):
        super(Cfc1, self).__init__()
        self.conv = nn.Sequential(
            conv_bn(3, 32, 11,4,2),  #55*55*32
            conv_bn(32, 128, 7,2,2),  #27*27*128
            conv_ccn(128,256,512,3,2,1),       #7*7*512
            nn.Conv2d(512,128,3, 1, 1, bias=False),#7*7*128              
            nn.Sigmoid( ))   
        
        self.fc = nn.Sequential(           
            nn.Linear(128*7*7,1024),
            nn.Dropout(p=0.5,inplace=False),
            nn.Linear(1024,clf_infeature))
        self._initialize_weights()
             

    def forward(self, x):
        x = self.conv(x) 
        x = x.view(x.size(0),-1) #28*28*64
        x = self.fc(x)            
        return x  
       

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()                 
                
                

class Cfcs(nn.Module):
    def __init__(self, clf_infeature=512):
        super(Cfcs, self).__init__()
        self.conv = nn.Sequential(
            conv_bn(3, 32, 11,4,2),  #55*55*32
            conv_bn(32, 128, 7,2,2),  #27*27*128
            conv_ccn(128,256,512,3,2,1),       #7*7*512
            nn.Conv2d(512,128,3, 1, 1, bias=False),#7*7*128  
            SELayer(128),
            nn.Sigmoid( ))   
        
        self.fc = nn.Sequential(           
            nn.Linear(128*7*7,1024),
            nn.Dropout(p=0.5,inplace=False),
            nn.Linear(1024,clf_infeature))
        self._initialize_weights()
             

    def forward(self, x):
        x = self.conv(x) 
        x = x.view(x.size(0),-1) #28*28*64
        x = self.fc(x)            
        return x  
       

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()                                
                
class Cfcms(nn.Module):
    def __init__(self, clf_infeature=512):
        super(Cfcms, self).__init__()
        self.conv = nn.Sequential(
            conv_bn(3, 32, 11,4,2),  #55*55*32
            conv_bn(32, 128, 7,2,2),  #27*27*128
            conv_bn(128, 256, 3,2,1),  #14*14*256
            M_attn(256,8),
            conv_bn(256, 512, 3,2,1),  #7*7*512
            M_attn(512,8),
            nn.Conv2d(512,128,3, 1, 1, bias=False),#7*7*128  
            M_attn(128,8),
            nn.Sigmoid( ))   
        
        self.fc = nn.Sequential(           
            nn.Linear(128*7*7,1024),
            nn.Dropout(p=0.5,inplace=False),
            nn.Linear(1024,clf_infeature))
        self._initialize_weights()
             

    def forward(self, x):
        x = self.conv(x) 
        x = x.view(x.size(0),-1) #28*28*64
        x = self.fc(x)            
        return x  
       

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_() 

    
def cfc(clf_infeature):
    model = Cfc(clf_infeature)
    return model   

def cfc1(clf_infeature):
    model = Cfc1(clf_infeature)
    return model  

def cfcs(clf_infeature):
    model = Cfcs(clf_infeature)
    return model   

def cfcms(clf_infeature):
    model = Cfcms(clf_infeature)
    return model  