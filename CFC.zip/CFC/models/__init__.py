from .init_model import init_loss, get_model
from .layers import ArcMarginProduct
from .layers import ArcMarginProduct_v2
from .layers import ArcMarginProduct_v3