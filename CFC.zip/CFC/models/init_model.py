#from .architectures import convergednet

from .architectures import cfc,cfc1,cfcs,cfcms,mobilenetv2,FeatherNetA,cdcn
from .layers import ArcMarginProduct, ArcMarginProduct_v2, ArcMarginProduct_v3, LinearSequential
import torch
import torch.nn as nn
import torchvision.models as models

#定义使用的模型、分类器和损失函数
def get_model(net_type, clf_type, clf_infeature, pretrained=False, output_size=2):
    if net_type == 'cfc': 
        model = cfc(clf_infeature) 
    elif net_type == 'cfc1': 
        model = cfc1(clf_infeature) 
    elif net_type == 'cfcs': 
        model = cfcs(clf_infeature) 
    elif net_type == 'cfcms': 
        model = cfcms(clf_infeature)  
    elif net_type == 'mobilenetv2': 
        model = mobilenetv2() 
    elif net_type == 'FeatherNet': 
        model = FeatherNetA()   
    elif net_type == 'CDCN': 
        model = cdcn()     
    elif net_type == 'googlenet': 
        model = models.googlenet(num_classes=2,aux_logits=False) 
        num_f = model.fc.in_features    #提取最后一个全连接层（fc）的输入特征数量
        model.fc = nn.Linear(num_f,clf_infeature)
    elif net_type == 'resnet18': 
        model = models.resnet18(pretrained=False) 
        num_f = model.fc.in_features    #提取最后一个全连接层（fc）的输入特征数量
        model.fc = nn.Linear(num_f,clf_infeature)
    elif net_type == 'vgg16': 
        model = models.vgg16(pretrained=False) 
        num_f = model.classifier[6].in_features    #提取最后一个全连接层（fc）的输入特征数量
        model.classifier[6] = nn.Linear(num_f,clf_infeature)
    elif net_type == 'alexnet': 
        model = models.alexnet(pretrained=False) 
        num_f = model.classifier[6].in_features    #提取最后一个全连接层（fc）的输入特征数量
        model.classifier[6] = nn.Linear(num_f,clf_infeature)
    else:
        raise Exception('Unknown architecture type')
    
            
    

    if clf_type == 'linear':
        classifier = nn.Linear(clf_infeature, output_size)
    elif clf_type == 'linear_sequential':
        classifier = LinearSequential(clf_infeature, [128, 2], [0.5, 0.])
    elif clf_type == 'arc_margin':
        classifier = ArcMarginProduct(clf_infeature, output_size)
    elif clf_type == 'arc_margin_5e-2':     #选用ArcMarginProduct损失函数作为分类器
        classifier = ArcMarginProduct(clf_infeature, output_size, m=0.05)
    elif clf_type == 'cce_arc_margin_1e-1':
        classifier = ArcMarginProduct_v2(clf_infeature, output_size, m=0.1)
    elif clf_type == 'cce_arc_margin_5e-2':
        classifier = ArcMarginProduct_v2(clf_infeature, output_size, m=0.05)
    elif clf_type == 'cce_arc_margin_14e+1':
        classifier = ArcMarginProduct_v2(clf_infeature, output_size, m=1.4)
    elif clf_type == 'cce_arc_margin_v3_1e-2_alpha_1e-1':
        classifier = ArcMarginProduct_v3(clf_infeature, output_size, m=0.01)
    elif clf_type == 'linear_bce':
        classifier = nn.Linear(clf_infeature, 1)
    else:
        raise Exception('Unknown clf type')
    
    return model, classifier   

class FocalLoss(nn.Module):
    def __init__(self, gamma = 2, eps = 1e-7):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.eps = eps
        self.ce = nn.CrossEntropyLoss()

    def forward(self, input, target):
        logp = self.ce(input, target)
        p = torch.exp(-logp)
        loss = (1 - p) ** self.gamma * logp
        return loss.mean()
    
def init_loss(criterion_name):

    if criterion_name=='bce':
        loss = nn.BCEWithLogitsLoss()
    elif criterion_name=='cce':   #选用交叉熵损失作为损失函数
        loss = nn.CrossEntropyLoss()
    elif criterion_name.startswith('arc_margin'):
        loss = nn.CrossEntropyLoss()
    elif 'cce' in criterion_name:
        loss = nn.CrossEntropyLoss()
    elif criterion_name == 'focal_loss':
        loss = FocalLoss()
    else:
        raise Exception('This loss function is not implemented yet.') 

    return loss 
