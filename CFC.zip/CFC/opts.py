import argparse, os, json
import torch
import torchvision as tv
import torchvision.transforms as transforms
#from utils import transforms

def get_opts():
    opt = argparse.Namespace()
    opt.exp_name = '12877_d'
    opt.task_name = ''    
    opt.fold = 1
    opt.data_root = 'D:\\lcy\\feathernet\\dataset\\'    
    opt.val = False #验证或测试标识.为真时，进行验证；为假时，进行测试
    
    opt.out_root = 'data\\opts\\'
    opt.out_path = os.path.join(opt.out_root,opt.exp_name,'fold{fold_n}'.format(fold_n=opt.fold))
    opt.pretraind_path = os.path.join(opt.out_path,'checkpoints','84_best.pth.tar')  
    #加载预训练模型的存储路径，加载时更改参数best.pth.tar为预训练模型的的名字
    
    ### Dataloader options ###
    opt.nthreads = 10         #windows系统下线程只能为0
    opt.batch_size = 32    #运行时改大点，原来是128
    opt.ngpu = 2

    ### Learning ###
    opt.freeze_epoch = 0
    opt.optimizer_name = 'Adam'          #使用Adam优化器
    opt.weight_decay = 0
    opt.lr = 2e-5
    opt.lr_decay_lvl = 0.5
    opt.lr_decay_period = 20
    opt.lr_type = 'cosine_repeat_lr'         #学习率的类型为cosine_repeat_lr
    opt.num_epochs = 100          #原来是50
    opt.resume = '41_best.pth.tar' #测试时，改为最佳模型的参数文件，如'116.pth.tar',训练时，值为False
    opt.debug = 0
    ### Other ###  
    opt.manual_seed = 704
    opt.log_batch_interval=10
    opt.log_checkpoint = 1
    opt.net_type = 'cfc1'            #使用cfc作为网络模型
    opt.pretrained = False    #加载预训练参数时，设置为True.训练时设置为False
    opt.classifier_type = 'arc_margin_5e-2'       #使用ArcMarginProduct(512, output_size, m=0.05)作为分类器
    opt.classifier_infeature = 512        #分类器输入特征
    opt.img_type = 'depth'
    opt.loss_type= 'cce'                   #使用交叉熵损失作为损失函数
    opt.alpha_scheduler_type = None             #alpha_scheduler定义为None,返回None
    opt.nclasses = 2
    opt.fake_class_weight = 1
    
    
    
    opt.train_transform = transforms.Compose([
            transforms.RandomRotation(30, resample=2),
            transforms.Resize((256,256)),          #
            transforms.RandomResizedCrop(224, scale=(0.5, 1.0)),        #
            transforms.RandomHorizontalFlip(p=0.3),            
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.4914, 0.4822, 0.4465], std=[0.2023, 0.1994, 0.2010])
        ])

    opt.test_transform = transforms.Compose([
            transforms.Resize((256,256)),            
            transforms.RandomHorizontalFlip(p=0),
            transforms.RandomResizedCrop(224, scale=(0.5, 1.0)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.4914, 0.4822, 0.4465], std=[0.2023, 0.1994, 0.2010])
        ])
    
    opt.train_transform1 = transforms.Compose([
            transforms.RandomRotation(30, resample=2),
            transforms.Resize((300,300)),          #
            transforms.RandomResizedCrop(256, scale=(0.5, 1.0)),        #
            transforms.RandomHorizontalFlip(p=0.3),            
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.4914, 0.4822, 0.4465], std=[0.2023, 0.1994, 0.2010])
        ])

    opt.test_transform1 = transforms.Compose([
            transforms.Resize((300,300)),            
            transforms.RandomHorizontalFlip(p=0),
            transforms.RandomResizedCrop(256, scale=(0.5, 1.0)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.4914, 0.4822, 0.4465], std=[0.2023, 0.1994, 0.2010])
        ])
   
    
    return opt


if __name__=='__main__':
    parser = argparse.ArgumentParser(description='Options')
    parser.add_argument('--savepath', type=str, default = 'data/opts/', help = 'Path to save options')
    conf = parser.parse_args()
    opts = get_opts()
    #save_dir = os.path.join(conf.savepath, opts.exp_name)
    if not os.path.isdir(conf.savepath):
        os.makedirs(conf.savepath)
    filename = os.path.join(conf.savepath + '_' + 'fold{0}'.format(opts.fold) + '_' + opts.task_name+'.opt')
    torch.save(opts, filename)
    print('Options file was saved to '+filename)
