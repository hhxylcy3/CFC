import torch.utils.data as data
import torch
from PIL import Image
import pandas as pd
import numpy as np
import os

import torch.utils.data as data

def rgb_loader(path):
    return Image.open(path)


class ImageListDataset(data.Dataset):
    """
    data_root - 训练图像根目录
    data_list - train集地址列表
    """
    def __init__(self,net_type, data_root, data_list, transform=None, transform1=None):
        self.net_type = net_type         
        self.data_root = data_root
        #self.df = pd.read_csv(data_list)
        self.df = pd.read_csv(data_list)
        if 'label' not in self.df.columns:
            self.df['label'] = -1
        self.transform = transform
        self.transform1 = transform1
        self.loader = rgb_loader

    def __getitem__(self, index):
                
        depth_path = self.data_root + self.df.img_path.iloc[index]
        target = self.df.label.iloc[index]
        depth_img = self.loader(depth_path)
        
        if self.net_type == 'CDCN' and self.transform is not None:            
            depth_img = self.transform1(depth_img)
        else:
            depth_img = self.transform(depth_img)
            
        return depth_img,target

   

    def __len__(self):
        return len(self.df)